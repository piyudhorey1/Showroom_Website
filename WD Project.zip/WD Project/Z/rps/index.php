<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="starter-template.css">
	 <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/all.min.css">
<title>Piyush Dhorey's -  Rock Paper Scissors</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1 class="display-5">Welcome to Rock Paper Scissors</h1>
<p>
 <a href="login.php>" button type="button" class="btn btn-link btn-lg">Please Log in</button></a>
</p>
<p>
Attempt to go to 
<a href="game.php">game.php</a> without logging in - it should fail with an error message.
<p>
<a href="http://www.wa4e.com/code/rps.zip"
 target="_blank">Source Code for this Application</a>
</p>
</div>
</body>

